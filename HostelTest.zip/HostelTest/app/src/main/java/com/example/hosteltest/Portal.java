package com.example.hosteltest;

public class Portal {

    private boolean Apply;

    public boolean isApply() {
        return Apply;
    }

    public void setApply(boolean apply) {
        Apply = apply;
    }
}
