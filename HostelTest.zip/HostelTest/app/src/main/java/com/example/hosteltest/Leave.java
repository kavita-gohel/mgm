package com.example.hosteltest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

import java.util.Calendar;

public class Leave extends AppCompatActivity {

    TextView name;
    FirebaseAuth auth;
    DatabaseReference reff,reffs;
    TextView sdate,edate;
    EditText details;
    String sdt,edt;
    int dayOfMonth;
    int year,month,date;
    long id = 0;
    int j=0;
    Calendar calender;
    DatePickerDialog datePickerDialog;
    Button btn_sdate,btn_edate,btn_submit;
    Student[] stu = new Student[100];
    int daystart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leave);

        auth = FirebaseAuth.getInstance();
        reff = FirebaseDatabase.getInstance().getReference().child("leaverequest");
        reffs = FirebaseDatabase.getInstance().getReference().child("Student");
        sdate = (TextView) findViewById(R.id.viewStart);
        edate = (TextView) findViewById(R.id.viewEnd);
        details = (EditText) findViewById(R.id.leaveDetail);
        btn_submit = (Button) findViewById(R.id.btnok);
        btn_sdate = (Button) findViewById(R.id.leaveStart);
        btn_edate = (Button) findViewById(R.id.leaveEnd);
        name = (TextView) findViewById(R.id.textViewName);

        String em = auth.getCurrentUser().getEmail();
        name.setText(em);

        btn_sdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calender = Calendar.getInstance();
                year = calender.get(Calendar.YEAR);
                month = calender.get(Calendar.MONTH);
                dayOfMonth = calender.get(Calendar.DAY_OF_MONTH);

                datePickerDialog = new DatePickerDialog(Leave.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                                sdate.setText(dayOfMonth +"/"+ (month+1) +"/"+ year);
                                daystart=dayOfMonth;
                            }
                        },year,month,dayOfMonth);
                long now = System.currentTimeMillis() - 1000;

                datePickerDialog.getDatePicker().setMinDate(now);
                datePickerDialog.getDatePicker().setMaxDate(now + (1000*60*60*24*7));
                datePickerDialog.show();
            }
        });
        btn_edate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calender = Calendar.getInstance();
                year = calender.get(Calendar.YEAR);
                month = calender.get(Calendar.MONTH);
                dayOfMonth = calender.get(Calendar.DAY_OF_MONTH);

                datePickerDialog = new DatePickerDialog(Leave.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                                if(dayOfMonth>=daystart) {
                                    edate.setText(dayOfMonth + "/" + (month + 1) + "/" + year);
                                }
                                else{
                                    Toast.makeText(Leave.this, "Please check the dates..!!", Toast.LENGTH_SHORT).show();
                                }
                            }
                        },year,month,dayOfMonth);
                long now = System.currentTimeMillis() - 1000;

                datePickerDialog.getDatePicker().setMinDate(now);
                datePickerDialog.getDatePicker().setMaxDate(now + (1000*60*60*24*7));
                datePickerDialog.show();

            }
        });
        reff.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                {
                    id = dataSnapshot.getChildrenCount();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        reffs.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot ds : dataSnapshot.getChildren() )
                {
                    stu[j] = (Student) ds.getValue();
                    j++;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LeaveRequest lr = new LeaveRequest();
                lr.setStart_date(sdate.getText().toString().trim());
                lr.setEnd_date(edate.getText().toString().trim());
                lr.setDescription(details.getText().toString().trim());
                lr.setEmail(name.getText().toString().trim());
                reff.child(String.valueOf(id+1)).setValue(lr);
            }
        });


    }
}
