package com.example.hosteltest;

public class Room {

    public int stu1;
    public int stu2;
    public int stu3;
}
