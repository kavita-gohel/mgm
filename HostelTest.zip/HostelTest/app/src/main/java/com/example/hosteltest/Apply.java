package com.example.hosteltest;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;

public class Apply extends AppCompatActivity {

    private Button btnSubmit;
    EditText name,phone,roll, acpcrank,email,p_email;
    Spinner citySpinner,castSpinner;
    Student student;
    DatabaseReference reff;

    Button ch;
    ImageView img;
    StorageReference mStorageRef;
    EditText txtname,txtdetail;
    public Uri imguri;
    private StorageTask uploadTask;
    //long id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apply);

        name = (EditText) findViewById(R.id.name);
        phone = (EditText) findViewById(R.id.phoneNumber);
        roll = (EditText) findViewById(R.id.rollNumber);
        castSpinner = (Spinner) findViewById(R.id.castSpinner);
        acpcrank = (EditText) findViewById(R.id.acpcrank);
        btnSubmit = (Button) findViewById(R.id.btnSubmit);
        email = (EditText) findViewById(R.id.sendEmail);
        p_email = (EditText) findViewById(R.id.parentEmail);
        citySpinner = (Spinner) findViewById(R.id.citySpinner);
        student = new Student();
        reff = FirebaseDatabase.getInstance().getReference().child("Student");

        reff.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                {
                    student.id = (int) dataSnapshot.getChildrenCount();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        mStorageRef= FirebaseStorage.getInstance().getReference("Images");
        reff= FirebaseDatabase.getInstance().getReference().child("Student");
        ch=(Button)findViewById(R.id.choosebutton);
        img=(ImageView)findViewById(R.id.imageView);
        student = new Student();

        ch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Filechooser();
            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                student.setName(name.getText().toString().trim());
                student.setPhone(phone.getText().toString().trim());
                student.setRoll(roll.getText().toString().trim());
                student.setSendemail(email.getText().toString().trim());
                student.setParent_email(p_email.getText().toString().trim());
                student.setAcpcrank(acpcrank.getText().toString().trim());
                student.setCast(castSpinner.getSelectedItem().toString().toLowerCase().trim());
                student.setCity(citySpinner.getSelectedItem().toString().trim());
                student.setStatus(false);
                reff.child(String.valueOf(acpcrank.getText().toString())+" "+(student.id)).setValue(student);


                if (uploadTask != null && uploadTask.isInProgress()) {
                    Toast.makeText(Apply.this, "Upload in Progress", Toast.LENGTH_LONG).show();
                } else {
                    Fileuploader();
                }

                Toast.makeText(Apply.this,"SUCCESS",Toast.LENGTH_LONG).show();
                Intent i = new Intent(Apply.this,Login.class);
                startActivity(i);
            }
        });

    }

    private String getExtension(Uri uri){
        ContentResolver cr=getContentResolver();
        MimeTypeMap mimeTypeMap=MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(cr.getType(uri));
    }

    private void Fileuploader()
    {
        String imageid;
        imageid=System.currentTimeMillis()+"."+getExtension(imguri);
        //data.setName(txtname.getText().toString().trim());
        // data.setDetail(txtdetail.getText().toString().trim());
        student.setImageid(imageid);
        reff.push().setValue(student);
        StorageReference Ref = mStorageRef.child(imageid);
        uploadTask=Ref.putFile(imguri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot> () {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        // Get a URL to the uploaded content
                        //Uri downloadUrl = taskSnapshot.getDownloadUrl();
                        Toast.makeText(Apply.this, "Image uploaded", Toast.LENGTH_LONG).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener () {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        // Handle unsuccessful uploads
                        // ...
                    }
                });
    }

    private void Filechooser()
    {
        Intent intent = new Intent();
        intent.setType("image/'");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1 && resultCode==RESULT_OK && data!=null && data.getData()!=null);
        {
            imguri= data.getData();
            img.setImageURI(imguri);
        }
    }

}